# 1.0.0

- Ported DronemeldDevotionFix code, stripped the dronemeld dependency and made the mod good