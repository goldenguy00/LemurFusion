# 1.0.2

- Fixed LemurianNames incompat for real this time

- Removed some debug logs

- Disabled size scaling until I make it work properly

# 1.0.1

- Fixed LemurianNames incompat

# 1.0.0

- Ported DronemeldDevotionFix code, stripped the dronemeld dependency and made the mod good